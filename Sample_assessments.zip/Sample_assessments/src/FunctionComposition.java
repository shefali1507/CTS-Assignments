import java.util.function.Function;

public class FunctionComposition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Function<Integer, Integer> multiply = (value) -> value *2 ;
		Function<Integer, Integer> add = (value) -> value +3 ;
		Function<Integer, Integer> multiplyThenAdd = multiply.andThen(add);
		Integer result = multiplyThenAdd.apply(3);
		System.out.println("The Result is" +result);
	}

}
