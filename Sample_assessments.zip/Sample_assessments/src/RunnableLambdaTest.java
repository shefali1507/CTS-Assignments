
public class RunnableLambdaTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable run = () ->  {
			System.out.println("Lamba Runnable in Action!");
		};
		new Thread(run).start();

	}

}
