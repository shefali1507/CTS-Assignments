import java.util.function.Function;

public class FindLengthOfString {

	public static void main(String[] args) {
		// Returning the length of the string
		Function<String, Integer> funcn = s -> s.length();
		System.out.println(" Length of String 'shefali' is:"+ funcn.apply("shefali"));
		
		//returning the string in lower case
		Function<String, String> funcn1 = s -> s.toLowerCase();
		System.out.println(" LowerCase of String 'SHEFALI' is:"+ funcn1.apply("SHEFALI"));
	}

}
