import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Comparator;

public class SortingListOfStringByLength {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> name = new ArrayList<>(Arrays.asList("Shefali", "Ashwin"));
		System.out.println("the original list without sorting");
		System.out.println(name);
		name.sort((first, second) -> Integer.compare(first.length(), second.length()));
		System.out.println("the list with sorting");
		System.out.println(name);

	}

}
