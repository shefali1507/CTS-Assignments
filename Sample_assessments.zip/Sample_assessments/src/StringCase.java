import java.util.Arrays;
import java.util.List;

public class StringCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> list = Arrays.asList("Shefali", "Ashwin");
		list.stream().map(name -> name.toUpperCase()).forEach(name -> System.out.println("names"+ " "));

	}

}
