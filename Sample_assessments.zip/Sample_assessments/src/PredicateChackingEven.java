import java.util.function.Predicate;

public class PredicateChackingEven {

	public static void main(String[] args) {
		// Checking Number is Even or Odd
		Predicate<Integer> pre1 = i -> i%2 ==0;
		System.out.println("Whether number 10 is even/odd \t:" + pre1.test(10)); //true=even and false =odd
		System.out.println("Whether number 11 is even/odd \t:" + pre1.test(11));
		
		// Checking String's length is greater than 5
		Predicate<String> pre2 = s -> s.length() > 5;
		System.out.println("Whether shefali contains length > 5 \t:" + pre2.test("shefali")); //true=greater and false =smaller
		System.out.println("Whether hello 11 ontains length > 5 \t:" + pre2.test("hello"));
		
		
		//Combine the two predicates to check a list of strings and filter out those that are even in length and 
		//have a length greater than 5.
		Predicate<Integer> pre3 = i -> i%2 ==0;
		Predicate<Integer> pre4 = s -> s > 5;
		int numbers[] = {25, 35, 50, 60, 75, 90, 100};
		for (int num : numbers) {
			if(pre3.and(pre4).test(num)) {
				System.out.println(num+"is even as well as greater than 5");
			}
		}
	}

}
