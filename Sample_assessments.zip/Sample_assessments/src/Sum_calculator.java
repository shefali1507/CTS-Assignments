
interface Sum_cal {
	int sum(int a, int b);
}
public class Sum_calculator {
public static void main(String[] args) {
	Sum_cal sumcal = (x, y) -> x + y;
	int result = sumcal.sum(1, 2);
	System.out.println("(sum of (1,2) =" + result);
	result = sumcal.sum(90, -5);
	System.out.println("(sum of (90,-5) =" + result);
}
}

